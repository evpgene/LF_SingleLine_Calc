classdef ShortCircuitClass < handle
    %SHORTCIRCUITCLASS Summary of this class goes here
    %   Detailed explanation goes here

    properties
        ZA
        ZB
        ZAmean
        ZBmean
    end

    methods
        function obj = ShortCircuitClass(SC_A,SC_B)
            %SHORTCIRCUITCLASS Construct an instance of this class
            %   Detailed explanation goes here
            obj.ZA = transpose(complex(SC_A.R,SC_A.X));
            obj.ZB = transpose(complex(SC_B.R,SC_B.X));
            obj.ZAmean = mean(obj.ZA);
            obj.ZBmean = mean(obj.ZB);
        end

        function Z = getZ(obj,N)
            % Импеданс
            % Если номер позиции 2 - возвращает импеданс для позиции B,
            % иначе для позиции A
            switch N
                case 2
                    Z = obj.ZB;
                otherwise
                    Z = obj.ZA;
            end
        end
        function Z = getZmean(obj,N)
            % Импеданс средний по трем электродам
            % Если номер позиции 2 - возвращает средний по трем электродам импеданс для позиции B,
            % иначе для позиции A
            switch N
                case 2
                    Z = obj.ZBmean;
                otherwise
                    Z = obj.ZAmean;
            end
        end
    end
end
