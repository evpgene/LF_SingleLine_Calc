classdef BalanceCalculationClass < handle
    %UNTITLED5 Summary of this class goes here
    %   Detailed explanation goes here
    % использую для индекса is, js чтобы не конфликтовать с мнимой
    % частью, где корень из минус 1 обозначается i или j
    properties
        % Ulin_1
        % U_HV = zeros(3);
        Rarc_max = 100; % проверить
        Npoints = 1000;
        % %dRarc = 0.1; % проверить - дельта изменения сопротивления дуги

        NetworkTransformer
        Reactor
        FurnaceTransformer
        ShortCircuit

        Ntap





    end

    methods
        function obj = BalanceCalculationClass(NetworkTransformerData,ReactorData,FurnaceTransformerData,SC_A, SC_B)
            %UNTITLED5 Construct an instance of this class
            %   Detailed explanation goes here
            obj.NetworkTransformer = NetworkTransformerClass(NetworkTransformerData);
            obj.Reactor = ReactorClass(ReactorData);
            obj.FurnaceTransformer = FurnaceTransformerClass(FurnaceTransformerData);
            obj.ShortCircuit = ShortCircuitClass(SC_A, SC_B);
            obj.Ntap = size(FurnaceTransformerData,1);
        end




        function r = computeOneTap(obj, Uhv,Ntr, Nre,Nntr,Npos,THD)

            K = obj.FurnaceTransformer.getK(Ntr);

            Z2uptoMV_mean = obj.FurnaceTransformer.getZ(Ntr) + obj.Reactor.getZ(Nre,K) + ...
                obj.ShortCircuit.getZmean(Npos);  % импеданс пересчитанный ...
            % на вторичную сторону печного трансформатора исключая сетевой
            % трансформатор (до среднего напряжения)

            Z2uptoHV_mean = Z2uptoMV_mean + ...
                obj.NetworkTransformer.getZ(Nntr,K); % импеданс...
            % пересчитанный на вторичную сторону печного трансформатора включая сетевой ...
            % трансформатор (до высокого напряжения)

            Rarc =linspace(0, obj.Rarc_max,obj.Npoints); % заполняет массив с заданным шагом
            Zarc = complex(Rarc,Rarc.*THD);

            r.Z2_LV_tot = Zarc + obj.ShortCircuit.getZmean(Npos);
            r.Z2_MV_tot = Zarc + Z2uptoMV_mean;
            r.Z2_HV_tot = Zarc + Z2uptoHV_mean;
            r.U2_ph = obj.FurnaceTransformer.getE2(obj.NetworkTransformer.getE2(Uhv,Nntr),Ntr)/sqrt(3);
            r.I2 = r.U2_ph./r.Z2_HV_tot;

            r.Parc = abs(r.I2).^2.*real(Zarc)./1000.0*3.0;
            r.Sarc = r.I2.^2.*Zarc./1000.0*3.0;
            r.Uarc = r.I2.*real(Zarc);
            r.Larc =  r.Uarc-40.0;         
            r.Ploss_MV = real(Z2uptoMV_mean)*abs(r.I2).^2.*3/1000;
            r.absI2 = abs(r.I2);
        end

        function r = compute(obj, Uhv, Nre,Nntr,Npos,THD)

            r.Z2_LV_tot = zeros(obj.Npoints,obj.Ntap);
            r.Z2_MV_tot = zeros(obj.Npoints,obj.Ntap);
            r.Z2_HV_tot = zeros(obj.Npoints,obj.Ntap);
            r.U2_ph = zeros(1,obj.Ntap);
            r.I2  = zeros(obj.Npoints,obj.Ntap);
            r.Parc  = zeros(obj.Npoints,obj.Ntap);
            r.Sarc  = zeros(obj.Npoints,obj.Ntap);
            r.Uarc  = zeros(obj.Npoints,obj.Ntap);
            r.Larc  = zeros(obj.Npoints,obj.Ntap);
            r.Ploss_MV  = zeros(obj.Npoints,obj.Ntap);

            for i = 1:9
                tmp = computeOneTap(obj, Uhv,i, Nre,Nntr,Npos,THD);

                r.Z2_LV_tot(:,i) = transpose(tmp.Z2_LV_tot);
                r.Z2_MV_tot(:,i) = transpose(tmp.Z2_MV_tot);
                r.Z2_HV_tot(:,i) = transpose(tmp.Z2_HV_tot);
                r.U2_ph(1,i) = transpose(tmp.U2_ph);
                r.I2(:,i)  = transpose(tmp.I2);
                r.Parc(:,i)  = transpose(tmp.Parc);
                r.Sarc(:,i)  = transpose(tmp.Sarc);
                r.Uarc(:,i)  = transpose(tmp.Uarc);
                r.Larc(:,i)  = transpose(tmp.Larc);
                r.Ploss_MV(:,i)  = transpose(tmp.Ploss_MV);
            end
        end
    end
end

