classdef ReactorClass < handle
    % Импеданс реактора
    % Вычисляет импеданс реактора, приведённый ко вторичной стороне печного
    % трансформатора

    properties
        Z
    end

    methods
        function obj = ReactorClass(ReactorData)
            R = ReactorData.R;
            X = ReactorData.X;
            obj.Z = complex(R,X);
        end

        function Z = getZ(obj,N,K)
            % импеданс
            % возвращает импеданс для заданной ступени и заданного
            % коэффициента трансформации печного трансформатора
            % N - ступень реактора
            % K - коэффициент трансформации печного трансформатора
            Z = obj.Z(N)/K^2;
        end
    end
end