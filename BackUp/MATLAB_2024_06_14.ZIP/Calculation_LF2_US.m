

%ShortCircuit = ShortCircuitClass(SC_A, SC_B);
BalanceCalculation = BalanceCalculationClass(NetworkTransformerData,ReactorData,FurnaceTransformerData, SC_A, SC_B);

%X = createArray(dims,"classname")


 r = BalanceCalculation.compute(220000,1,9,1,0.06);

% plot(abs(r.I2), r.Parc);
% plot(abs(r.Z2_HV_tot), r.Parc);



% конструктор окна диаграммы
f = figure("Name",'ступень сетевого трансформатора = 9');
% отключить строку меню
f.MenuBar = "none";
f.ToolBar = "none";
%   отключить 'figure n' в ярлыке окна 
f.NumberTitle = "off";

% построить график
h = plot(abs(r.I2), real(r.Larc));
% толщина линий
set(h,LineWidth=1.25);

% Размер шрифта
fontsize(f,12,"points")
% Заголовок и название осей
title('Длина дуги','ступень сетевого трансформатора = 9','FontSize',14)
xlabel('Ток, [кА]')
ylabel('Длина дуги, [мм]')
% сетка
grid on
% легенда
label = {'1' '2' '3' '4' '5' '6' '7' '8' '9'};
legend(label,'Location','best');


%legend({txt,'Позиция 2','Позиция 3','Позиция 4','Позиция 5','Позиция 6','Позиция 7','Позиция 8','Позиция 9'},'Location','best')
