
Ulin_1 = 220000*dU1;
Ktr_HV(3) = 6.2857;
Ktr_HV(1) = Ktr_HV(3)*0.95;
Ktr_HV(2) = Ktr_HV(3)*0.975;
Ktr_HV(4) = Ktr_HV(3)*1.025;
Ktr_HV(5) = Ktr_HV(3)*1.05;

Ntr_HV = 3;

Pos = 1;

switch Pos
    case 1
        Zsc = Zsc_A;
    case 2
        Zsc = Zsc_B;
    otherwise
        Zsc = Zsc_A;
end;










Ztr2_tmp = complex(SourceData.Rtr2_phOhm,SourceData.Xtr2_phOhm);
Ztr1 = complex(SourceData.Rtr1_phOhm,SourceData.Xtr1_phOhm);
Zre1 = complex(SourceData.Rre1_phOhm, SourceData.Xre1_phOhm);
Zsumm1 = complex(SourceData.Rsumm1Ohm, SourceData.Xsumm1Ohm);
Z1 = Ztr1 + Zre1 + Zsumm1;
Ztr2 = Ztr1./TransformerData.K.^2*1000 + Ztr2_tmp;
Zre2 = Zre1./TransformerData.K.^2*1000;
Zsumm2 = Zsumm1./TransformerData.K.^2*1000;
Zsc_A = transpose(complex(SC_A.R,SC_A.X));
Zsc_B = transpose(complex(SC_B.R,SC_B.X));
Zsc_A_mean = mean(Zsc_A);
Zsc_B_mean = mean(Zsc_B);

switch Pos
    case 1
        Zsc_mean = Zsc_A_mean;
    case 2
        Zsc_mean = Zsc_B_mean;
    otherwise
        Zsc_mean = Zsc_A_mean;
end;


Z2_HV_mean = Ztr2 + Zre2 + Zsumm2 + Zsc_A_mean;
Z2_MV_mean = Ztr2 + Zre2 + Zsc_A_mean;
% ��������� �����
dUtr_110_35 = 1.02;
dU1 = 1.0;
dU = dUtr_110_35 * dU1;
THD = 0.07;
Ntr = 9;
Rarc_max = 100;
dRarc = 0.1;
Npoints = Rarc_max/0.1;
%
% Zarc = zeros(Npoints,1);
Rarc = zeros(Npoints,1);
% Xarc = zeros(Npoints,1);

for j = 1:1:Npoints
    Rarc(j,1) = double(dRarc*(j-1));
end

Zarc = complex(Rarc,Rarc.*THD);
Z2_MV_tot = zeros(Npoints,Ntr);
Z2_HV_tot = zeros(Npoints,Ntr);
Z2_tot = zeros(Npoints,Ntr);
I2 = zeros(Npoints,Ntr);
Parc = zeros(Npoints,Ntr);
Sarc = zeros(Npoints,Ntr);
Uarc = zeros(Npoints,Ntr);
Larc = zeros(Npoints,Ntr);
Ploss_MV = zeros(Npoints,Ntr);
for i = 1:1:Ntr
    for j = 1:1:Npoints
        Z2_MV_tot(j,i) = Zarc(j,1) + Z2_MV_mean(i);
        Z2_HV_tot(j,i) = Zarc(j,1) + Z2_HV_mean(i);
        Z2_tot(j,i) = Zarc(j,1) + Zsc_mean;
        I2(j,i) = TransformerData.U2ph(i)*dU/Z2_HV_tot(j,i);
        Parc(j,i) = abs(I2(j,i))^2*real(Zarc(j))/1000.0*3.0;
        Sarc(j,i) = I2(j,i)^2*Zarc(j)/1000.0*3.0;
        Uarc(j,i) = I2(j,i)*real(Zarc(j));
        Larc(j,i) = Uarc(j,i)-40.0;
        Ploss_MV(j,i) = real(Z2_MV_mean(i))*abs(I2(j,i))^2*3/1000;
    end
end;

S_MV = Z2_MV_tot.*I2.^2*3/1000;
S_MVtst = abs(S_MV);
S_HV = Z2_HV_tot.*I2.^2*3/1000;
S_HVtst = abs(S_HV);

I2tst = abs(I2);
Parctst = abs(Sarc);
dParctst = Parc - Parctst;
PF2 = cos(angle(I2));
Uarctsts = abs(Uarc);
HII = Parc.*abs(I2);
% HIItst = abs(HII);
RI = Parc.*abs(Uarc);
% RItst = real(Sarc).*abs(Uarc);
% RItst1 = abs(Sarc.*Uarc);
% Zarc_arr = zeros(21,3);
Z2arr =  zeros(Ntr,3);
for i = 1:1:Ntr
    for j = 1:1:3
        Z2arr(i,j) = Zsc_A(j) + Zarc(i);
    end
end


abs_I2 = abs(I2);
abs_Parc = abs(Parc);
abs_Larc = abs(Larc);
abs_RI = abs(RI);
% abs_RI = abs_RI/10;
abs_HII = abs(HII);

% figure('Name','Parc/Z2')
% plot(abs(Z2_tot),abs(Parc));
% figure('Name','HII/Z2')
% plot(abs(Z2_tot),abs(HII));
% figure('Name','I2/Z2')
% plot(abs(I2),abs(Z2_tot));
% 
% figure
% plot(abs(I2),abs(Parc));

% figure('Name','Uarc/Z2')
% plot(abs(Z2_tot),abs(Uarc));

% figure('Name','Larc/I2')
% plot(abs(I2),abs(Larc));
% 
% % figure('Name','RI/Z2')
% % plot(abs(Z2_tot),abs(RI));
% figure('Name','RI/I2')
% plot(abs(I2),abs(RI));
% figure('Name','HII/I2')
% plot(abs(I2),abs(HII));

% 







plot(abs(I2),abs(Parc));

%  plot(abs(I2),abs(Parc),abs(I2),abs(HII),abs(I2),abs(RI));
% plot(abs(I2),abs(HII),abs(I2),abs(RI));

% plot(abs(I2),abs(Ploss_MV));
% plot(abs(I2),Rarc);

% plot(imag(S_MV),real(S_MV));
% plot(real(S_MV),imag(S_MV));
% plot(real(S_MV),abs(imag(S_MV)));
% plot(real(S_MV),(S_MV));
% plot(real(S_MV),abs(S_MV));
% pl  ot(abs(S_HV),abs(S_MV));
% plot(abs(I2),abs(S_MV));
% figure

% figure
% plot(abs(I2),abs(RI));


        
% U_HV(1) = complex(Ulin_1/sqrt(3)*cos(0),Ulin_1(1,1)/sqrt(3)*sin(0));
% U_HV(2) = complex(Ulin_1/sqrt(3)*cos(2*pi()/3),Ulin_1(1,1)/sqrt(3)*sin(2*pi()/3));
% U_HV(3) = complex(Ulin_1/sqrt(3)*cos(4*pi()/3),Ulin_1(1,1)/sqrt(3)*sin(4*pi()/3));

U_HV(1) = complex(Ulin_1/sqrt(3)*cos(4*pi()/3),Ulin_1(1,1)/sqrt(3)*sin(4*pi()/3));
U_HV(2) = complex(Ulin_1/sqrt(3)*cos(0*pi()/3),Ulin_1(1,1)/sqrt(3)*sin(0*pi()/3));
U_HV(3) = complex(Ulin_1/sqrt(3)*cos(2*pi()/3),Ulin_1(1,1)/sqrt(3)*sin(2*pi()/3));





E = zeros(Ntr,3);
U_MV = U_HV./Ktr_HV(Ntr_HV);

Zsum = zeros(Ntr,3);
% a = zeros(Ntr,3);
% b = zeros(Ntr,3);
% c = zeros(Ntr,3);
% d = zeros(Ntr,3);
Rdset = zeros(Ntr,3);
Zdset = zeros(Ntr,3);
Zsettst = zeros(Ntr,3);



% Zset = zeros(Ntr,3);
%   setpoints  Z 
% for i = 1:1:Ntr
%     for j = 1:1:3
%         Zset(i,j) = 30;
%      end
% end         
% Zset(1,1) = 4.525;
% Zset(1,2) =4.163;
% Zset(1,3) = 4.177;
% 
% Zset(2,1) = 7.38;
% Zset(2,2) = 7.38;
% Zset(2,3) = 7.38;
% 
% 
% Zset(3,1) = 4.525;
% Zset(3,2) =4.163;
% Zset(3,3) = 4.177;
% Zset(4,1) = 4.525;
% Zset(4,2) =4.163;
% Zset(4,3) = 4.177;
% Zset(5,1) = 4.525;
% Zset(5,2) =4.163;
% Zset(5,3) = 4.177;
% Zset(6,1) = 4.525;
% Zset(6,2) =4.163;
% Zset(6,3) = 4.177;
% Zset(7,1) = 4.525;
% Zset(7,2) =4.163;
% Zset(7,3) = 4.177;
% Zset(8,1) = 4.525;
% Zset(8,2) =4.163;
% Zset(8,3) = 4.177;
% Zset(9,1) = 4.525;
% Zset(9,2) =4.163;
% Zset(9,3) = 4.177;
% Zset(10,1) = 4.525;
% Zset(10,2) =4.163;
% Zset(10,3) = 4.177;
% Zset(11,1) = 4.525;
% Zset(11,2) =4.163;
% Zset(11,3) = 4.177;
% 
% Zset(12,1) = 7.96;
% Zset(12,2) = 7.41;
% Zset(12,3) = 7.72;
% 
% Zset(13,1) = 4.525;
% Zset(13,2) =4.163;
% Zset(13,3) = 4.177;
% Zset(14,1) = 4.525;
% Zset(14,2) =4.163;
% Zset(14,3) = 4.177;
% Zset(15,1) = 4.525;
% Zset(15,2) =4.163;
% Zset(15,3) = 4.177;
% 
% Zset(16,1) = 4.19;
% Zset(16,2) =4.53;
% Zset(16,3) = 4.09;
% 
% Zset(17,1) = 4.80;
% Zset(17,2) = 4.97;
% Zset(17,3) = 4.75;
% Zset(18,1) = 5.46;
% Zset(18,2) = 5.46;
% Zset(18,3) = 5.46;
% Zset(19,1) = 5.46;
% Zset(19,2) = 5.46;
% Zset(19,3) = 5.46;
% Zset(20,1) = 5.6;
% Zset(20,2) = 5.26;
% Zset(20,3) = 5.33;
% Zset(22,1) = 6.9;
% Zset(22,2) = 6.9;
% Zset(22,3) = 6.9;
% 
%//////////////////

for i = 1:1:Ntr
    for j = 1:1:3
        E(i,j) = U_MV(j)/TransformerData.K(i)*dU;
        Zsum(i,j) = Zsc(j)+Zre2(i)+Ztr2(i)+Zsumm2(i);
    end
end  

for i = 1:1:Ntr
    for j = 1:1:3
%       Square equation fo calculate Rdset
        a = (1+THD^2);
        b = 2*(imag(Zsc(j))*THD + real(Zsc(j)));
        c =  real(Zsc(j))^2 + imag(Zsc(j))^2 - Zset(i,j)^2;
        D = b^2-4*a*c;
        Rdset(i,j) = (-b+sqrt(D))/(2*a);
        %calculation control
        Zsettst(i,j) = sqrt((Rdset(i,j)+real(Zsc(j)))^2 + (Rdset(i,j)*THD+imag(Zsc(j)))^2);
        Zdset(i,j) = complex(Rdset(i,j),Rdset(i,j)*THD);
    end
end
Zarcx = Zdset;


 %/////////////////////calculation///////////////////////                        

    Ztotal = Zarcx + Zsum;
    Y=1./Ztotal;
    Ysum = zeros(Ntr,1);
    for i = 1:1:Ntr
            Ysum(i) = Y(i,1)+Y(i,2)+Y(i,3);
    end
    Ix = zeros(Ntr,3);
    for i = 1:1:Ntr
        for j = 1:1:3
    Ix(i,j) = E(i,j)*Y(i,j);
        end
    end
    Ixsum = zeros(Ntr,1);
    for i = 1:1:Ntr
            Ixsum(i) = Ix(i,1)+Ix(i,2)+Ix(i,3);
    end
    UnN = Ixsum./Ysum;
    UNn = - UnN;
    UN = zeros(Ntr,3);
    for i = 1:1:Ntr
        for j = 1:1:3
            UN(i,j) = UNn(i) + E(i,j);
        end
    end
    I = UN./Ztotal;
    Iabs = abs(I);
    Iabs_x = abs(Ix);
    Z2x = zeros(Ntr,3);
    Uarcx = zeros(Ntr,3);
    Parcx = zeros(Ntr,3);
    HIIx = zeros(Ntr,3);
    RIx = zeros(Ntr,3);
    Larcx = zeros(Ntr,3);
    Stab = zeros(Ntr,3);
    for i = 1:1:Ntr
        for j = 1:1:3
            Z2x(i,j)= Zsc(j)+ Zarcx(i,j);
            Stab(i,j) = imag(Z2x(i,j))/imag(Zsc(j));
%             Uarcx(i,j) = real(Zarcx(i,j))* Iabs(i,j);
            Uarcx(i,j) = abs(real(Zarcx(i,j))* I(i,j));
            Larcx(i,j) = Uarcx(i,j)-40;
            HIIx(i,j) = Uarcx(i,j)*Iabs(i,j)^2;
            RIx(i,j) = Uarcx(i,j)^2*Iabs(i,j)/1000;
            Parcx(i,j) = Uarcx(i,j)*Iabs(i,j);
        end
    end
    
    Parc_summ_x = zeros(Ntr,1);
    HII_summ_x = zeros(Ntr,1);
    RI_summ_x = zeros(Ntr,1);
    I_mean_x = zeros(Ntr,1);
    
    for i = 1:1:Ntr

        I_mean_x(i,1) = (Iabs(i,1)+Iabs(i,2)+Iabs(i,3))/3;
        HII_summ_x(i,1) = HIIx(i,1)+HIIx(i,2)+HIIx(i,3);
        RI_summ_x(i,1) = (RIx(i,1)+RIx(i,2)+RIx(i,3));
        Parc_summ_x(i,1) = Parcx(i,1)+Parcx(i,2)+Parcx(i,3);
  
    end

    
    Z2x_abs = abs(Z2x);
    %////////////////////end calculation

 